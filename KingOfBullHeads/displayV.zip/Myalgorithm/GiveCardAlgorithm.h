#ifndef GIVECARDALGORITHM_H
#define GIVECARDALGORITHM_H
#include <vector>
#include <random>
#include <algorithm>
namespace GiveCard
{
    class ThreeUnion
    {
    public:
        std::vector<int> v1;
        std::vector<int> v2;
        std::vector<int> v3;
        ThreeUnion(const std::vector<int>& a1,const std::vector<int>& a2,const std::vector<int>& a3):v1(a1),v2(a2),v3(a3){};
    };
    ThreeUnion Init1v1()
    {
        std::random_device rd;
        std::mt19937 gen(rd());
        gen.seed(123);
        int lowerBound = 1;
        int upperBound = 104;

        std::vector<int> numbers;
        for (int i = lowerBound; i <= upperBound; ++i)
        {
            numbers.push_back(i);
        }
        std::shuffle(numbers.begin(), numbers.end(), gen);
        std::vector<int> me;
        std::vector<int> AI;
        std::vector<int> slot;
        for (size_t i = 0; i < 10; ++i)
        {
            me.push_back(numbers[i]);
            AI.push_back(numbers[i + 10]);
        }
        for(size_t j=20;j<=23;j++)
        {
            slot.push_back(numbers[j]);
        }
        std::sort(me.begin(),me.end());
        std::sort(AI.begin(),AI.end());
        return ThreeUnion(me,AI,slot);

    }
}
#endif // GIVECARDALGORITHM_H
