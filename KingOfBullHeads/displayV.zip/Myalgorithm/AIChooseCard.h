#ifndef AICHOOSECARD_H
#define AICHOOSECARD_H
#include <vector>
#include <random>
#include <algorithm>
#include <QList>
#include <card.h>
namespace EasyAI
{
    int ChooseACard(std::vector<int> card)
    {
        std::mt19937 gen;
        gen.seed(123);
        std::sort(card.begin(),card.end());
        std::uniform_int_distribution<> dist(0, card.size() - 1);
        size_t randomIndex = dist(gen);
        int randomNumber = card[randomIndex];
        return randomNumber;
    }
    int ChooseARow(QList<MyCard*>& line1, QList<MyCard*>& line2, QList<MyCard*>& line3, QList<MyCard*>& line4)
    {
        int sum[4]{0,0,0,0};
        for(auto it:line1)
            sum[0] += it->heads_num;
        for(auto it:line2)
            sum[1] += it->heads_num;
        for(auto it:line3)
            sum[2] += it->heads_num;
        for(auto it:line4)
            sum[3] += it->heads_num;
        int min_index = -1;
        int min = 550;
        for(int i = 0;i < 4;i++)
        {
            if(sum[i] < min)
            {
                min = sum[i];
                min_index = i;
            }
        }
        return min_index;
    }
}
//namespace NormAI
//{
//    void ChooseACard()
//    {

//    }
//}
//namespace HardAI
//{
//    void ChooseACard()
//    {

//    }
//}
#endif // AICHOOSECARD_H
