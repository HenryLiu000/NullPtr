#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "MyPushButton.h"
#include <QDebug>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <beginscene.h>
#include <Myalgorithm/GiveCardAlgorithm.h>
#include <Myalgorithm/AIChooseCard.h>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowIcon(QIcon(":/res/Res/Icon.ico"));
    setWindowTitle("Who is the king of bull heads?");
    ui->stackedWidget->setCurrentIndex(0);
    //ui->stackedWidget->show();
    //Start
    connect(ui->beginscene->start,&MyPushButton::clicked,this,&MainWindow::Start_Clicked);
    //Setting
    connect(ui->beginscene->setting,&MyPushButton::clicked,this,&MainWindow::Setting_Clicked);
    //Rule
    connect(ui->beginscene->rule,&MyPushButton::clicked,this,&MainWindow::Rule_Clicked);
    //Quitgame
    connect(ui->beginscene->Quitgame,&MyPushButton::clicked,this,&MainWindow::Quitgame_Clicked);
}
void MainWindow::Start_Clicked()
{
    ui->choosemodescene = new ChooseModeScene(ui->centralwidget);
    ui->stackedWidget->addWidget(ui->choosemodescene);
    ui->stackedWidget->setCurrentIndex(1);
    connect(ui->choosemodescene->Quit,&MyPushButton::clicked,this,&MainWindow::QuitChooseMode_Clicked);
    connect(ui->choosemodescene->Guy2,&MyPushButton::clicked,this,&MainWindow::Guy2Choose);
    connect(ui->choosemodescene->Guy4,&MyPushButton::clicked,this,&MainWindow::Guy4Choose);
}

//MainMenu按钮
void MainWindow::Setting_Clicked()
{

}
void MainWindow::Rule_Clicked()
{

}
void MainWindow::Quitgame_Clicked()
{
    delete ui->stackedWidget->widget(0);
    this->close();
}
void MainWindow::QuitChooseMode_Clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
    ui->beginscene->bgm->play();/*刷夜勿用*/
    delete ui->stackedWidget->widget(1);
}

//人数选择按钮
void MainWindow::Guy2Choose()
{
    ui->Guy2modescene = new Guy2PlayModeChoose(ui->centralwidget);
    ui->stackedWidget->addWidget(ui->Guy2modescene);
    ui->stackedWidget->setCurrentIndex(2);
    connect(ui->Guy2modescene->MainMenu,&MyPushButton::clicked,this,&MainWindow::Guy2ChooseReturnToMainMenu);
    connect(ui->Guy2modescene->Return,&MyPushButton::clicked,this,&MainWindow::Guy2ChooseReturnToChooseMode);

    connect(ui->Guy2modescene->Easy, &MyPushButton::clicked, this, &MainWindow::EasyPlay1v1);
    connect(ui->Guy2modescene->Medium, &MyPushButton::clicked, this, &MainWindow::NormalPlay1v1);
    connect(ui->Guy2modescene->Hard, &MyPushButton::clicked, this, &MainWindow::HardPlay1v1);

}
void MainWindow::Guy4Choose()
{
    ui->Guy4modescene = new Guy4PlayModeChoose(ui->centralwidget);
    ui->stackedWidget->addWidget(ui->Guy4modescene);
    ui->stackedWidget->setCurrentIndex(2);
    connect(ui->Guy4modescene->MainMenu,&MyPushButton::clicked,this,&MainWindow::Guy2ChooseReturnToMainMenu);
    connect(ui->Guy4modescene->Return,&MyPushButton::clicked,this,&MainWindow::Guy2ChooseReturnToChooseMode);
    connect(ui->Guy4modescene->Easy, &MyPushButton::clicked, this, &MainWindow::EasyPlay1v3);

    connect(ui->Guy4modescene->Medium, &MyPushButton::clicked, this, &MainWindow::NormalPlay1v3);
    connect(ui->Guy4modescene->Hard, &MyPushButton::clicked, this, &MainWindow::HardPlay1v3);
}

//二人对战操作
void MainWindow::Guy2ChooseReturnToMainMenu()
{
    ui->stackedWidget->setCurrentIndex(0);
    ui->beginscene->bgm->play();/*刷夜勿用*/
    delete ui->stackedWidget->widget(2);
    delete ui->stackedWidget->widget(1);
}
void MainWindow::Guy2ChooseReturnToChooseMode()
{
    ui->stackedWidget->setCurrentIndex(1);
    ui->beginscene->bgm->play();/*刷夜勿用*/
    delete ui->stackedWidget->widget(2);
}

//四人混战操作
void MainWindow::Guy4ChooseReturnToMainMenu()
{
    ui->stackedWidget->setCurrentIndex(0);
    ui->beginscene->bgm->play();/*刷夜勿用*/
    delete ui->stackedWidget->widget(2);
    delete ui->stackedWidget->widget(1);
}
void MainWindow::Guy4ChooseReturnToChooseMode()
{
    ui->stackedWidget->setCurrentIndex(1);
    ui->beginscene->bgm->play();/*刷夜勿用*/
    delete ui->stackedWidget->widget(2);
}

//选择简单1v1模式
void MainWindow::EasyPlay1v1()
{
    ui->play1v1scene = new Play1v1(0,ui->centralwidget);
    ui->stackedWidget->addWidget(ui->play1v1scene);
    ui->stackedWidget->setCurrentIndex(3);
    //确认创建角色
    connect(ui->play1v1scene->confirm_create_player, &MyPushButton::clicked, this, &MainWindow::Play1v1ConfirmCreatePlayer);
    //点击主菜单
    connect(ui->play1v1scene->main_menu, &MyPushButton::clicked, ui->play1v1scene, &Play1v1::click_Main_menu);
    //点击退出
    connect(ui->play1v1scene->quit, &MyPushButton::clicked, this, &MainWindow::Play1v1ToBeginscene);
}
//选择中等难度1v1
void MainWindow::NormalPlay1v1(){
    ui->play1v1scene = new Play1v1(1,ui->centralwidget);
    ui->stackedWidget->addWidget(ui->play1v1scene);
    ui->stackedWidget->setCurrentIndex(3);
    //确认创建角色
    connect(ui->play1v1scene->confirm_create_player, &MyPushButton::clicked, this, &MainWindow::Play1v1ConfirmCreatePlayer);
    //点击主菜单
    connect(ui->play1v1scene->main_menu, &MyPushButton::clicked, ui->play1v1scene, &Play1v1::click_Main_menu);
    //点击退出
    connect(ui->play1v1scene->quit, &MyPushButton::clicked, this, &MainWindow::Play1v1ToBeginscene);
}
//选择困难难度1v1
void MainWindow::HardPlay1v1(){
    ui->play1v1scene = new Play1v1(2,ui->centralwidget);
    ui->stackedWidget->addWidget(ui->play1v1scene);
    ui->stackedWidget->setCurrentIndex(3);
    //确认创建角色
    connect(ui->play1v1scene->confirm_create_player, &MyPushButton::clicked, this, &MainWindow::Play1v1ConfirmCreatePlayer);
    //点击主菜单
    connect(ui->play1v1scene->main_menu, &MyPushButton::clicked, ui->play1v1scene, &Play1v1::click_Main_menu);
    //点击退出
    connect(ui->play1v1scene->quit, &MyPushButton::clicked, this, &MainWindow::Play1v1ToBeginscene);
}

//选择简单1v3模式
void MainWindow::EasyPlay1v3(){
    ui->play1v3scene = new Play1v3(ui->centralwidget);
    ui->stackedWidget->addWidget(ui->play1v3scene);
    ui->stackedWidget->setCurrentIndex(3);
    //确认创建角色
    connect(ui->play1v3scene->confirm_create_player, &MyPushButton::clicked, this, &MainWindow::Play1v3ConfirmCreatePlayer);
    //点击主菜单
    connect(ui->play1v3scene->main_menu, &MyPushButton::clicked, ui->play1v3scene, &Play1v3::click_Main_menu);
    //点击退出
    connect(ui->play1v3scene->quit, &MyPushButton::clicked, this, &MainWindow::Play1v3ToBeginscene);
}
//选择中等难度1v3
void MainWindow::NormalPlay1v3(){
    ui->play1v3scene = new Play1v3(ui->centralwidget);
    ui->stackedWidget->addWidget(ui->play1v3scene);
    ui->stackedWidget->setCurrentIndex(3);
    //确认创建角色
    connect(ui->play1v3scene->confirm_create_player, &MyPushButton::clicked, this, &MainWindow::Play1v3ConfirmCreatePlayer);
    //点击主菜单
    connect(ui->play1v3scene->main_menu, &MyPushButton::clicked, ui->play1v3scene, &Play1v3::click_Main_menu);
    //点击退出
    connect(ui->play1v3scene->quit, &MyPushButton::clicked, this, &MainWindow::Play1v3ToBeginscene);
}
//选择困难难度1v3
void MainWindow::HardPlay1v3(){
    ui->play1v3scene = new Play1v3(ui->centralwidget);
    ui->stackedWidget->addWidget(ui->play1v3scene);
    ui->stackedWidget->setCurrentIndex(3);
    //确认创建角色
    connect(ui->play1v3scene->confirm_create_player, &MyPushButton::clicked, this, &MainWindow::Play1v3ConfirmCreatePlayer);
    //点击主菜单
    connect(ui->play1v3scene->main_menu, &MyPushButton::clicked, ui->play1v3scene, &Play1v3::click_Main_menu);
    //点击退出
    connect(ui->play1v3scene->quit, &MyPushButton::clicked, this, &MainWindow::Play1v3ToBeginscene);
}


//确认创建角色
void MainWindow::Play1v1ConfirmCreatePlayer()
{
    if(ui->play1v1scene->lineEdit->text()!=""){
        QString inputText = ui->play1v1scene->lineEdit->text();
        ui->play1v1scene->ME->player_name = inputText;
        qDebug()<<"input:"<<inputText;
    }
    else{
        QString NullName = "Alice";
        ui->play1v1scene->ME->player_name = NullName;
        qDebug()<<"input:"<<NullName;
    }
    ui->play1v1scene->ME->show();
    ui->play1v1scene->Bob->show();
    ui->play1v1scene->cardslot->show();
    ui->play1v1scene->line[0]->show();
    ui->play1v1scene->line[1]->show();
    ui->play1v1scene->line[2]->show();
    ui->play1v1scene->line[3]->show();
    ui->play1v1scene->buffer[0]->show();
    ui->play1v1scene->buffer[1]->show();
    //做几个cardslot代表游戏桌的四行
    ui->play1v1scene->lineEdit->hide();
    ui->play1v1scene->confirm_create_player->hide();
    ui->play1v1scene->title->hide();
    ui->play1v1scene->MYLabel->setText(ui->play1v1scene->ME->player_name);
    ui->play1v1scene->MYLabel->setAlignment(Qt::AlignCenter);
    ui->play1v1scene->MYLabel->setStyleSheet("font-size: 40px");
    ui->play1v1scene->BobLabel->setText("EasyAI");
    ui->play1v1scene->BobLabel->setAlignment(Qt::AlignCenter);
    ui->play1v1scene->BobLabel->setStyleSheet("font-size: 40px");
    ui->play1v1scene->MYHeads->setText(QString::number(ui->play1v1scene->ME->heads_num));
    ui->play1v1scene->MYHeads->setAlignment(Qt::AlignCenter);
    ui->play1v1scene->MYHeads->setStyleSheet("font-size: 40px");
    ui->play1v1scene->BobHeads->setText(QString::number(ui->play1v1scene->Bob->heads_num));
    ui->play1v1scene->BobHeads->setAlignment(Qt::AlignCenter);
    ui->play1v1scene->BobHeads->setStyleSheet("font-size: 40px");
    ui->play1v1scene->MYLabel->show();
    ui->play1v1scene->BobLabel->show();
    ui->play1v1scene->MYHeads->show();
    ui->play1v1scene->BobHeads->show();
    //初始化游戏完毕，开始发牌
    GiveCard::ThreeUnion three = GiveCard::Init1v1();
    ui->play1v1scene->ME->cards_in_hands = three.v1;
    ui->play1v1scene->Bob->cards_in_hands = three.v2;
    for(auto it : three.v1)
    {
        MyCard* tmp = new MyCard(ui->play1v1scene->cardslot,it,160,250);
        connect(tmp,&MyPushButton::clicked,this,&MainWindow::SomeCard_Clicked);
        ui->play1v1scene->cardslot->cards.push_back(tmp);
        ui->play1v1scene->cardslot->cardSlotLayout->addWidget(tmp);
    }
    for(auto it:ui->play1v1scene->cardslot->cards)
    {
        it->show();
    }
    MyCard* tmp1 = new MyCard(ui->play1v1scene->cardslot,three.v3[0],128,200);
    tmp1->is_play=1;
    ui->play1v1scene->line[0]->cards.push_back(tmp1);
    ui->play1v1scene->line[0]->cardSlotLayout->addWidget(tmp1);
    ui->play1v1scene->line[0]->lastnum = three.v3[0];
    tmp1->show();
    MyCard* tmp2 = new MyCard(ui->play1v1scene->cardslot,three.v3[1],128,200);
    tmp2->is_play=1;
    ui->play1v1scene->line[1]->cards.push_back(tmp2);
    ui->play1v1scene->line[1]->cardSlotLayout->addWidget(tmp2);
    ui->play1v1scene->line[1]->lastnum = three.v3[1];
    tmp2->show();
    MyCard* tmp3 = new MyCard(ui->play1v1scene->cardslot,three.v3[2],128,200);
    tmp3->is_play=1;
    ui->play1v1scene->line[2]->cards.push_back(tmp3);
    ui->play1v1scene->line[2]->cardSlotLayout->addWidget(tmp3);
    ui->play1v1scene->line[2]->lastnum = three.v3[2];
    tmp3->show();
    MyCard* tmp4 = new MyCard(ui->play1v1scene->cardslot,three.v3[3],128,200);
    tmp4->is_play=1;
    ui->play1v1scene->line[3]->cards.push_back(tmp4);
    ui->play1v1scene->line[3]->cardSlotLayout->addWidget(tmp4);
    ui->play1v1scene->line[3]->lastnum = three.v3[3];
    tmp4->show();
    connect(ui->play1v1scene->cancel_play_card,&MyPushButton::clicked,this,&MainWindow::Cancel_Play_Card);
    connect(ui->play1v1scene->confirm_play_card,&MyPushButton::clicked,this,&MainWindow::Confirm_Play_Card);
//    MyCard* ToRemove = qobject_cast<MyCard*>(ui->play1v1scene->cardslot->cardSlotLayout->itemAt(0)->widget());
//    ui->play1v1scene->cardslot->cardSlotLayout->removeWidget(ToRemove);
//    delete ToRemove;
    //AI mode选择
//    switch (ui->play1v1scene->whichmode)
//    {
//    case 0:
//        break;
//    case 1:
//        break;
//    case 2:
//        break;
//    }

}

//以下三个函数是出牌的关键，需要严格把握好以下几个重要的量：
//(1)明确ui->current_choose_card是哪个，便于Confirm_Play_Card出牌
//(2)每次点击一张牌后、点击另一张牌、点击取消后，相关牌的is_clicked是怎样的
void MainWindow::SomeCard_Clicked()
{
    MyCard* clickedButton = qobject_cast<MyCard*>(sender());
    if(ui->current_choose_card == nullptr)
    {
        ui->current_choose_card = clickedButton;
        ui->play1v1scene->confirm_play_card->show();
        ui->play1v1scene->cancel_play_card->show();
    }
    else
    {
        if(ui->current_choose_card == clickedButton)
        {
            ui->current_choose_card = nullptr;
            ui->play1v1scene->confirm_play_card->hide();
            ui->play1v1scene->cancel_play_card->hide();
        }
        else
        {
            ui->current_choose_card->move(ui->current_choose_card->x(),ui->current_choose_card->y() + 30);
            ui->current_choose_card->is_clicked = 0;
            ui->current_choose_card = clickedButton;
        }
    }
}
void MainWindow::Cancel_Play_Card()
{
    ui->current_choose_card->is_clicked = 0;
    ui->current_choose_card->move(ui->current_choose_card->x(),ui->current_choose_card->y()+30);
    ui->current_choose_card = nullptr;
    ui->play1v1scene->confirm_play_card->hide();
    ui->play1v1scene->cancel_play_card->hide();
}
void MainWindow::Confirm_Play_Card()
{
    int my_num = ui->current_choose_card->card_number;
    ui->play1v1scene->confirm_play_card->hide();
    ui->play1v1scene->cancel_play_card->hide();
    int pos = ui->play1v1scene->cardslot->cardSlotLayout->indexOf(ui->current_choose_card);//获取当前card的位置
    //维护
    ui->play1v1scene->cardslot->cards.erase(ui->play1v1scene->cardslot->cards.begin() + pos);
    ui->play1v1scene->cardslot->cardSlotLayout->removeWidget(ui->current_choose_card);
    delete ui->current_choose_card;
    ui->current_choose_card = nullptr;

    MyCard* mycard = new MyCard(ui->play1v1scene->buffer[0], my_num, 160, 250);
    mycard->is_play=1;
    //AI出牌
    int AI_choice = 0;
    switch (ui->play1v1scene->whichmode)
    {
    case 0:
        AI_choice = EasyAI::ChooseACard(ui->play1v1scene->Bob->cards_in_hands);
        break;
    case 1:
        //AI_choice = NormAI::ChooseACard(ui->play1v1scene->Bob->cards_in_hands,...);
        break;
    case 2:
        //AI_choice = HardAI::ChooseACard(ui->play1v1scene->Bob->cards_in_hands,...);
        //因为此时玩家已经confirm了，因此可以通过ui->current_choose_card得到玩家的牌传进函数里，耍赖
        break;
    }
    auto itt = std::find(ui->play1v1scene->Bob->cards_in_hands.begin(),ui->play1v1scene->Bob->cards_in_hands.end(),AI_choice);
    ui->play1v1scene->Bob->cards_in_hands.erase(itt);
    MyCard* AIcard = new MyCard(ui->play1v1scene->buffer[0], AI_choice, 160, 250);
    AIcard->is_play=1;
    ui->play1v1scene->buffer[0]->cardSlotLayout->addWidget(mycard);
    ui->play1v1scene->buffer[1]->cardSlotLayout->addWidget(AIcard);
    mycard->show();
    AIcard->show(); 
    // Pause the program for the 5s to display the screen to the audience.
    QEventLoop loop;
    QTimer::singleShot(3000, &loop, &QEventLoop::quit);
    loop.exec();
    mycard->hide();
    AIcard->hide();
    MyPushButton* toline[4]={ui->play1v1scene->toline1,ui->play1v1scene->toline2,
                             ui->play1v1scene->toline3,ui->play1v1scene->toline4};
    if(my_num < AI_choice)
    {
        int delta[4]={105, 105, 105, 105}, min=105, min_idx=0;
        bool check_if_min = true;                 //这张牌是否比所有槽都小
        for(int j = 0;j < 4;j++)
        {
            delta[j] = my_num - ui->play1v1scene->line[j]->lastnum;
            if(delta[j] < min && delta[j] > 0)
            {
                min = delta[j];
                min_idx = j;
            }
            if(delta[j] > 0)
            {
                check_if_min = false;
            }
        }
        if(check_if_min)
        {
            QEventLoop eventLoop;
            //替掉一个槽
            mycard->show();
            AIcard->show();
            for(int k=0;k<4;k++)
            {
                toline[k]->show();
            }
            //点不同的line按钮
            QPointer<QObject> myObject = this;
            for(int k = 0;k < 4;k++)
            {
                connect(toline[k],&QPushButton::clicked,&eventLoop,&QEventLoop::quit);
                connect(toline[k],&QPushButton::clicked,[&,myObject,k,toline,my_num]()mutable{
                    MyCard* MyCardtoslot = new MyCard(ui->play1v1scene->line[k], my_num, 128, 200);
                    MyCardtoslot->is_play=1;
                    if(myObject)
                    {
                        while (QLayoutItem* item = ui->play1v1scene->line[k]->cardSlotLayout->takeAt(0))
                        {
                            QWidget* widget = item->widget();
                            MyCard* tmpCard = qobject_cast<MyCard*>(widget);
                            // Check if the qobject_cast was successful
                            if (tmpCard)
                            {
                                ui->play1v1scene->ME->heads_num += tmpCard->heads_num;
                                delete widget;
                                widget = nullptr;
                                tmpCard = nullptr;
                            }
                            delete item;
                            item = nullptr;
                        }//将Layout中的全删掉
                        ui->play1v1scene->MYHeads->setText(QString::number(ui->play1v1scene->ME->heads_num));
                        ui->play1v1scene->line[k]->cards.clear();
                        ui->play1v1scene->line[k]->cards.push_back(MyCardtoslot);
                        ui->play1v1scene->line[k]->cardSlotLayout->addWidget(MyCardtoslot);
                        ui->play1v1scene->line[k]->lastnum = my_num;
                        for(int k=0;k<4;k++)
                        {
                            toline[k]->hide();
                            toline[k]->disconnect();
                        }
                    }

                });
            }
            eventLoop.exec();
            mycard->hide();
            AIcard->hide();
        }
        else
        {
            MyCard* MyCardtoslot = new MyCard(ui->play1v1scene->line[min_idx], my_num, 128, 200);
            MyCardtoslot->is_play=1;
            if(ui->play1v1scene->line[min_idx]->cards.size() == 5)//行满，被动吃分
            {
                while (QLayoutItem* item = ui->play1v1scene->line[min_idx]->cardSlotLayout->takeAt(0))
                {
                    QWidget* widget = item->widget();
                    MyCard* tmpCard = qobject_cast<MyCard*>(widget);
                    // Check if the qobject_cast was successful
                    if (tmpCard)
                    {
                        ui->play1v1scene->ME->heads_num += tmpCard->heads_num;
                        delete widget;
                        widget = nullptr;
                        tmpCard = nullptr;
                    }
                    delete item;
                    item = nullptr;
                }
                ui->play1v1scene->MYHeads->setText(QString::number(ui->play1v1scene->ME->heads_num));
                ui->play1v1scene->line[min_idx]->cards.clear();
                ui->play1v1scene->line[min_idx]->cards.push_back(MyCardtoslot);
                ui->play1v1scene->line[min_idx]->cardSlotLayout->addWidget(MyCardtoslot);
                ui->play1v1scene->line[min_idx]->lastnum = my_num;
//                for(int j=0;j<5;j++)
//                {
//                    ui->play1v1scene->line[min_idx]->cards[j]->hide();
//                }
            }
            else//行未满，向对应行里添牌
            {
                ui->play1v1scene->line[min_idx]->cards.push_back(MyCardtoslot);
                ui->play1v1scene->line[min_idx]->cardSlotLayout->addWidget(MyCardtoslot);
                ui->play1v1scene->line[min_idx]->lastnum = my_num;
            }
        }
        //再来给AI放牌
        int delta1[4] = {105, 105, 105, 105}, min1 = 105, min_idx1 = 0;
        bool check_if_min1 = true;                 //这张牌是否比所有槽都小
        for(int j = 0;j < 4;j++)
        {
            delta1[j] = AI_choice - ui->play1v1scene->line[j]->lastnum;
            if(delta1[j] < min1 && delta1[j] > 0)
            {
                min1 = delta1[j];
                min_idx1 = j;
            }
            if(delta1[j] > 0)
            {
                check_if_min1 = false;
            }
        }
        if(check_if_min1)
        {
            //AI选一行

            QList<MyCard*> Line[4] = {ui->play1v1scene->line[0]->cards,ui->play1v1scene->line[1]->cards,
                                       ui->play1v1scene->line[2]->cards,ui->play1v1scene->line[3]->cards};
            int k = EasyAI::ChooseARow(Line[0],Line[1],Line[2],Line[3]);
            MyCard* AICardtoslot = new MyCard(ui->play1v1scene->line[k], AI_choice, 128, 200);
            AICardtoslot->is_play=1;
            while (QLayoutItem* item = ui->play1v1scene->line[k]->cardSlotLayout->takeAt(0))
            {
                QWidget* widget = item->widget();
                MyCard* tmpCard = qobject_cast<MyCard*>(widget);
                // Check if the qobject_cast was successful
                if (tmpCard)
                {
                    ui->play1v1scene->Bob->heads_num += tmpCard->heads_num;//AI吃分
                    delete widget;
                    widget = nullptr;
                    tmpCard = nullptr;
                }
                delete item;
                item = nullptr;
            }//将Layout中的全删掉
            ui->play1v1scene->BobHeads->setText(QString::number(ui->play1v1scene->Bob->heads_num));
            ui->play1v1scene->line[k]->cards.clear();
            ui->play1v1scene->line[k]->cards.push_back(AICardtoslot);
            ui->play1v1scene->line[k]->cardSlotLayout->addWidget(AICardtoslot);
            ui->play1v1scene->line[k]->lastnum = AI_choice;
        }
        else
        {
            MyCard* AICardtoslot = new MyCard(ui->play1v1scene->line[min_idx1], AI_choice, 128, 200);
            AICardtoslot->is_play=1;
            if(ui->play1v1scene->line[min_idx1]->cards.size() == 5)//行满，被动吃分
            {
                while (QLayoutItem* item = ui->play1v1scene->line[min_idx1]->cardSlotLayout->takeAt(0))
                {
                    QWidget* widget = item->widget();
                    MyCard* tmpCard = qobject_cast<MyCard*>(widget);
                    // Check if the qobject_cast was successful
                    if (tmpCard)
                    {
                        ui->play1v1scene->Bob->heads_num += tmpCard->heads_num;
                        delete widget;
                        widget = nullptr;
                        tmpCard = nullptr;
                    }
                    delete item;
                    item = nullptr;
                }
                ui->play1v1scene->BobHeads->setText(QString::number(ui->play1v1scene->Bob->heads_num));
                ui->play1v1scene->line[min_idx1]->cards.clear();
                ui->play1v1scene->line[min_idx1]->cards.push_back(AICardtoslot);
                ui->play1v1scene->line[min_idx1]->cardSlotLayout->addWidget(AICardtoslot);
                ui->play1v1scene->line[min_idx1]->lastnum = AI_choice;
            }
            else//行未满，向对应行里添牌
            {
                ui->play1v1scene->line[min_idx1]->cards.push_back(AICardtoslot);
                ui->play1v1scene->line[min_idx1]->cardSlotLayout->addWidget(AICardtoslot);
                ui->play1v1scene->line[min_idx1]->lastnum = AI_choice;
            }
        }
    }
    else
    {
        //先给AI放牌
        int delta[4]={105, 105, 105, 105}, min = 105, min_idx=0;
        bool check_if_min = true;                 //这张牌是否比所有槽都小
        for(int j = 0;j < 4;j++)
        {
            delta[j] = AI_choice - ui->play1v1scene->line[j]->lastnum;
            if(delta[j] < min && delta[j] > 0)
            {
                min = delta[j];
                min_idx = j;
            }
            if(delta[j] > 0)
            {
                check_if_min = false;
            }
        }

        if(check_if_min)
        {
            QList<MyCard*> Line[4] = {ui->play1v1scene->line[0]->cards,ui->play1v1scene->line[1]->cards,
                                       ui->play1v1scene->line[2]->cards,ui->play1v1scene->line[3]->cards};
            int k = EasyAI::ChooseARow(Line[0],Line[1],Line[2],Line[3]);
            MyCard* AICardtoslot = new MyCard(ui->play1v1scene->line[k], AI_choice, 128, 200);
            AICardtoslot->is_play=1;
            while (QLayoutItem* item = ui->play1v1scene->line[k]->cardSlotLayout->takeAt(0))
            {
                QWidget* widget = item->widget();
                MyCard* tmpCard = qobject_cast<MyCard*>(widget);
                // Check if the qobject_cast was successful
                if (tmpCard)
                {
                    ui->play1v1scene->Bob->heads_num += tmpCard->heads_num;//AI吃分
                    delete widget;
                    widget = nullptr;
                    tmpCard = nullptr;
                }
                delete item;
                item = nullptr;
            }//将Layout中的全删掉
            ui->play1v1scene->BobHeads->setText(QString::number(ui->play1v1scene->Bob->heads_num));
            ui->play1v1scene->line[k]->cards.clear();
            ui->play1v1scene->line[k]->cards.push_back(AICardtoslot);
            ui->play1v1scene->line[k]->cardSlotLayout->addWidget(AICardtoslot);
            ui->play1v1scene->line[k]->lastnum = AI_choice;
        }
        else
        {
            MyCard* AICardtoslot = new MyCard(ui->play1v1scene->line[min_idx], AI_choice, 128, 200);
            AICardtoslot->is_play=1;
            if(ui->play1v1scene->line[min_idx]->cards.size()==5)//行满，被动吃分
            {
                while (QLayoutItem* item = ui->play1v1scene->line[min_idx]->cardSlotLayout->takeAt(0))
                {
                    QWidget* widget = item->widget();
                    MyCard* tmpCard = qobject_cast<MyCard*>(widget);
                            // Check if the qobject_cast was successful
                    if (tmpCard)
                    {
                        ui->play1v1scene->Bob->heads_num += tmpCard->heads_num;
                        delete widget;
                        widget = nullptr;
                        tmpCard = nullptr;
                    }
                    delete item;
                    item = nullptr;
                }
                ui->play1v1scene->BobHeads->setText(QString::number(ui->play1v1scene->Bob->heads_num));
                ui->play1v1scene->line[min_idx]->cards.clear();
                ui->play1v1scene->line[min_idx]->cards.push_back(AICardtoslot);
                ui->play1v1scene->line[min_idx]->cardSlotLayout->addWidget(AICardtoslot);
                ui->play1v1scene->line[min_idx]->lastnum = AI_choice;
            }
            else//行未满，向对应行里添牌
            {
                ui->play1v1scene->line[min_idx]->cards.push_back(AICardtoslot);
                ui->play1v1scene->line[min_idx]->cardSlotLayout->addWidget(AICardtoslot);
                ui->play1v1scene->line[min_idx]->lastnum = AI_choice;
            }
        }
        //再来给我放牌
        int delta1[4] = {105, 105, 105, 105}, min1 = 105, min_idx1 = 0;
        bool check_if_min1 = true;                 //这张牌是否比所有槽都小
        for(int j = 0;j < 4;j++)
        {
            delta1[j] = my_num - ui->play1v1scene->line[j]->lastnum;
            if(delta1[j] < min1 && delta1[j] > 0)
            {
                min1 = delta1[j];
                min_idx1 = j;
            }
            if(delta1[j] > 0)
            {
                check_if_min1 = false;
            }
        }
        if(check_if_min1)
        {
            //我选一行
            //替掉一个槽
            QEventLoop eventLoop;
            //替掉一个槽
            mycard->show();
            AIcard->show();
            for(int k=0;k<4;k++)
            {
                toline[k]->show();
            }
            //点不同的line按钮
            QPointer<QObject> myObject = this;
            for(int k=0;k<4;k++)
            {
                connect(toline[k],&QPushButton::clicked,&eventLoop,&QEventLoop::quit);
                connect(toline[k],&QPushButton::clicked,[&,myObject,k,toline]()mutable{
                    MyCard* MyCardtoslot = new MyCard(ui->play1v1scene->line[k], my_num, 128, 200);
                    MyCardtoslot->is_play=1;
                    if(myObject)
                    {
                        while (QLayoutItem* item = ui->play1v1scene->line[min_idx]->cardSlotLayout->takeAt(0))
                        {
                            QWidget* widget = item->widget();
                            MyCard* tmpCard = qobject_cast<MyCard*>(widget);
                            // Check if the qobject_cast was successful
                            if (tmpCard)
                            {
                                ui->play1v1scene->ME->heads_num += tmpCard->heads_num;//统计牛头数
                                delete widget;
                                widget = nullptr;
                                tmpCard = nullptr;
                            }
                            delete item;
                            item = nullptr;
                        }//将Layout中的全删掉
                        ui->play1v1scene->MYHeads->setText(QString::number(ui->play1v1scene->ME->heads_num));
                        ui->play1v1scene->line[min_idx]->cards.clear();
                        ui->play1v1scene->line[k]->cards.push_back(MyCardtoslot);
                        ui->play1v1scene->line[k]->cardSlotLayout->addWidget(MyCardtoslot);
                        ui->play1v1scene->line[k]->lastnum = my_num;//维持每行最后一数
                        for(int k=0;k<4;k++)
                        {
                            toline[k]->hide();
                            toline[k]->disconnect();
                        }
                    }
                });
            }
            eventLoop.exec();
            mycard->hide();
            AIcard->hide();
        }
        else
        {
            MyCard* MyCardtoslot = new MyCard(ui->play1v1scene->line[min_idx1], my_num, 128, 200);
            MyCardtoslot->is_play=1;
            if(ui->play1v1scene->line[min_idx1]->cards.size() == 5)//行满，被动吃分
            {
                while (QLayoutItem* item = ui->play1v1scene->line[min_idx1]->cardSlotLayout->takeAt(0))
                {
                    QWidget* widget = item->widget();
                    MyCard* tmpCard = qobject_cast<MyCard*>(widget);
                            // Check if the qobject_cast was successful
                    if (tmpCard)
                    {
                        ui->play1v1scene->ME->heads_num += tmpCard->heads_num;
                        delete widget;
                        widget = nullptr;
                        tmpCard = nullptr;
                    }
                    delete item;
                    item = nullptr;
                }
                ui->play1v1scene->MYHeads->setText(QString::number(ui->play1v1scene->ME->heads_num));
                ui->play1v1scene->line[min_idx1]->cards.clear();
                ui->play1v1scene->line[min_idx1]->cards.push_back(MyCardtoslot);
                ui->play1v1scene->line[min_idx1]->cardSlotLayout->addWidget(MyCardtoslot);
                ui->play1v1scene->line[min_idx1]->lastnum = my_num;
            }
            else//行未满，向对应行里添牌
            {
                ui->play1v1scene->line[min_idx1]->cards.push_back(MyCardtoslot);
                ui->play1v1scene->line[min_idx1]->cardSlotLayout->addWidget(MyCardtoslot);
                ui->play1v1scene->line[min_idx1]->lastnum = my_num;
            }
        }
    }
    ui->play1v1scene->buffer[0]->cardSlotLayout->removeWidget(mycard);
    ui->play1v1scene->buffer[1]->cardSlotLayout->removeWidget(AIcard);
    delete mycard;
    delete AIcard;
    if(ui->play1v1scene->cardslot->cards.size() == 0 )
    {

        //showfinishscence
        MainWindow::finish_a_game();
    }
}

void MainWindow::finish_a_game(){
    qDebug()<<"Hooray!";
    for(int i=0;i<4;i++){
        for(int j=0;j<ui->play1v1scene->line[i]->cards.size();j++){
            ui->play1v1scene->line[i]->cards[j]->hide();
        }
    }
    ui->play1v1scene->cardslot->setFixedSize(1, 1);
    for(int i=0;i<4;i++){
        ui->play1v1scene->line[i]->setFixedSize(1, 1);
    }
    ui->play1v1scene->loseImage = new MyPushButton(this, 0, ":/res/Res/losePic.png", ":/res/Res/losePic.png");
    ui->play1v1scene->loseImage->setFixedSize(800, 600);
    ui->play1v1scene->loseImage->move(400, 100);
    ui->play1v1scene->loseImage->hide();
    ui->play1v1scene->winImage = new MyPushButton(this, 0, ":/res/Res/victoryPic.png", ":/res/Res/victoryPic.png");
    ui->play1v1scene->winImage->setFixedSize(800, 600);
    ui->play1v1scene->winImage->move(400, 100);
    ui->play1v1scene->winImage->hide();
    ui->play1v1scene->tieImage = new MyPushButton(this, 0, ":/res/Res/pingjuPic.png", ":/res/Res/pingjuPic.png");
    ui->play1v1scene->tieImage->setFixedSize(800, 600);
    ui->play1v1scene->tieImage->move(400, 100);
    ui->play1v1scene->tieImage->hide();
    if(ui->play1v1scene->ME->heads_num < ui->play1v1scene->Bob->heads_num){
        ui->play1v1scene->winImage->show();
    }
    else if(ui->play1v1scene->ME->heads_num > ui->play1v1scene->Bob->heads_num){
        ui->play1v1scene->loseImage->show();
    }
    else{
        ui->play1v1scene->tieImage->show();
    }
    ui->play1v1scene->finish_button->show();
    connect(ui->play1v1scene->finish_button, &MyPushButton::clicked, this, &MainWindow::Play1v1ToBeginscene);
}

//确认创建角色
void MainWindow::Play1v3ConfirmCreatePlayer(){
    if(ui->play1v3scene->lineEdit->text()!=""){
        QString inputText = ui->play1v3scene->lineEdit->text();
        ui->play1v3scene->ME->player_name=inputText;
        qDebug()<<"input:"<<inputText;
    }
    else{
        QString NullName = "Alice";
        ui->play1v3scene->ME->player_name=NullName;
        qDebug()<<"input:"<<NullName;
    }
    ui->play1v3scene->lineEdit->hide();
    ui->play1v3scene->confirm_create_player->hide();
    ui->name_label = new QLabel(this);
    ui->name_label->setText(ui->play1v3scene->ME->player_name);
    ui->name_label->setGeometry(100, 180, 200, 40);
    ui->name_label->show();
}

void MainWindow::Play1v1ToBeginscene(){
    ui->stackedWidget->setCurrentIndex(0);
//    ui->beginscene->bgm->play();/*刷夜勿用*/
    if(ui->play1v1scene->winImage!=nullptr){
        ui->play1v1scene->winImage->hide();
    }
    if(ui->play1v1scene->loseImage!=nullptr){
        ui->play1v1scene->loseImage->hide();
    }
    if(ui->play1v1scene->tieImage!=nullptr){
        ui->play1v1scene->tieImage->hide();
    }
    delete ui->stackedWidget->widget(3);
    delete ui->stackedWidget->widget(2);
    delete ui->stackedWidget->widget(1);
    if(ui->name_label!=NULL){
        delete ui->name_label;
        ui->name_label=NULL;
    }
}
void MainWindow::Play1v3ToBeginscene(){
    ui->stackedWidget->setCurrentIndex(0);
//    ui->beginscene->bgm->play();/*刷夜勿用*/
    delete ui->stackedWidget->widget(3);
    delete ui->stackedWidget->widget(2);
    delete ui->stackedWidget->widget(1);
    if(ui->name_label!=NULL){
        delete ui->name_label;
        ui->name_label=NULL;
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

