#ifndef PLAY1V3_H
#define PLAY1V3_H

#include <QWidget>
#include <QSound>
#include <QLabel>
#include <QPropertyAnimation>
#include <QTimer>
#include <QDebug>
#include <QPainter>
#include <QImage>
#include <QLineEdit>
#include <QDebug>
#include "MyPushButton.h"
#include "player.h"

class Play1v3:public QWidget{
    Q_OBJECT
public:
    explicit Play1v3(QWidget* parent=0);
    void paintEvent(QPaintEvent *event);
    void click_Main_menu();
//    void mousePressEvent(QMouseEvent *event);
    MyPushButton* main_menu;  //主菜单
    MyPushButton* confirm_play_card;  //确认出牌
    MyPushButton* confirm_create_player;  //确认创建昵称
    MyPushButton* quit;  //主菜单中的退出游戏
    MyPlayer* ME;      //自己
    MyPlayer* Bob;     //对手1
    MyPlayer* Carol;   //对手2
    MyPlayer* Dave;    //对手3
    QLineEdit* lineEdit;
    bool is_show_main_menu=0;

signals:
    void show_menu();
    void quit_game();
};

#endif // PLAY1V3_H
