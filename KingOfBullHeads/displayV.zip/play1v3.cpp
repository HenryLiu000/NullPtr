#include "play1v3.h"

Play1v3::Play1v3(QWidget* parent):QWidget(parent){
    //输入昵称
    lineEdit = new QLineEdit(this);
    lineEdit->move(400, 300);
    lineEdit->setPlaceholderText("请输入昵称...");
    lineEdit->setClearButtonEnabled(true);
    //创建主菜单和创建角色两个按牛
    main_menu = new MyPushButton(this, "MainMenu");
    confirm_play_card = new MyPushButton(this, "PlayCard");
    confirm_create_player = new MyPushButton(this, "create player!");
    quit = new MyPushButton(this, "Quit!");
    quit->resize(150, 50);
    quit->move(650, 65);
    main_menu->resize(150, 50);
    main_menu->move(650, 10);
    confirm_create_player->resize(150, 50);
    confirm_create_player->move(400, 400);
    confirm_play_card->hide();
    quit->hide();
    //创建角色
    ME = new MyPlayer(this, "Alice", ":/res/Res/Alice.jpg");
    ME->move(100, 100);
    Bob = new MyPlayer(this, "Bob", ":/res/Res/Bob.jpg");
    Bob->move(100, 500);
    Carol = new MyPlayer(this,"Carol",":/res/Res/Carol.jpg");
    Carol->move(200,500);
    Dave = new MyPlayer(this,"Dave",":/res/Res/Dave.jpg");
    Dave->move(300,500);
}

void Play1v3::click_Main_menu(){
    if(!is_show_main_menu){
        quit->show();
        is_show_main_menu=1;
    }
    else{
        is_show_main_menu=0;
        quit->hide();
    }
}

void Play1v3::paintEvent(QPaintEvent *event){
    QWidget::paintEvent(event);

    QPainter painter(this);

    // 加载照片文件
    QImage image(":/res/Res/playbackground.png");
    // 在绘图设备上绘制照片
    painter.drawImage(rect(), image);
}
